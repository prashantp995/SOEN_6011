To achieve maintainability project is modularized 
Main.java file is under \Calculator\src\
Unit tests are under \UnitTest\src\

To execuate jar file run below code
java -jar 40046876_D2_Jar.jar