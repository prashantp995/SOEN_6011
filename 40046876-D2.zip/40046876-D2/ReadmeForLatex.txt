If require , you can view latex project for D2 at
https://www.overleaf.com/read/jwkxgzshjmvr