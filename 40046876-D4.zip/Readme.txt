if require , you can view latex and PDF file for D4  at :
https://www.overleaf.com/read/tgjwcchtppmt